mergemanager.exe 파일과
MergeCode.gpl 파일이 같은 폴더 안에 존재해야 합니다.